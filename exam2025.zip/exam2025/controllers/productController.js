const Product = require('../models/Product');
const Cart = require('../models/Cart');
const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
    destination: './public/uploads/',
    filename: function(req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({
    storage: storage,
    limits: { fileSize: 1000000 },
    fileFilter: function(req, file, cb) {
        checkFileType(file, cb);
    }
}).single('image');

function checkFileType(file, cb) {
    const filetypes = /jpeg|jpg|png|gif/;
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = filetypes.test(file.mimetype);

    if (mimetype && extname) {
        return cb(null, true);
    } else {
        cb('Error: Images Only!');
    }
}

exports.getAllProducts = async (req, res) => {
    try {
        const products = await Product.find();
        const cart = await Cart.findOne({ userId: req.user._id });
        res.render('products/index', { products, cart });
    } catch (err) {
        req.flash('error_msg', 'Error loading products');
        res.redirect('/');
    }
};

exports.createProduct = (req, res) => {
    upload(req, res, async (err) => {
        if (err) {
            req.flash('error_msg', err);
            return res.redirect('/products/create');
        }

        try {
            const { name, price, qty, description } = req.body;
            const newProduct = new Product({
                name,
                price,
                qty,
                description,
                image: `/uploads/${req.file.filename}`
            });
            await newProduct.save();
            req.flash('success_msg', 'Product added successfully');
            res.redirect('/products');
        } catch (err) {
            req.flash('error_msg', 'Error creating product');
            res.redirect('/products/create');
        }
    });
};

exports.updateProduct = async (req, res) => {
    try {
        const { name, price, qty, description } = req.body;
        await Product.findByIdAndUpdate(req.params.id, {
            name, price, qty, description
        });
        req.flash('success_msg', 'Product updated successfully');
        res.redirect('/products');
    } catch (err) {
        req.flash('error_msg', 'Error updating product');
        res.redirect('/products');
    }
};

exports.deleteProduct = async (req, res) => {
    try {
        await Product.findByIdAndDelete(req.params.id);
        req.flash('success_msg', 'Product deleted successfully');
        res.redirect('/products');
    } catch (err) {
        req.flash('error_msg', 'Error deleting product');
        res.redirect('/products');
    }
};