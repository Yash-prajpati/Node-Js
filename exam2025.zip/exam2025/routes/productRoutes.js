const express = require('express');
const router = express.Router();
const { ensureAuthenticated } = require('../middleware/auth');
const productController = require('../controllers/productController');

router.get('/', ensureAuthenticated, productController.getAllProducts);
router.get('/create', ensureAuthenticated, (req, res) => res.render('products/create'));
router.post('/', ensureAuthenticated, productController.createProduct);
router.put('/:id', ensureAuthenticated, productController.updateProduct);
router.delete('/:id', ensureAuthenticated, productController.deleteProduct);

module.exports = router;